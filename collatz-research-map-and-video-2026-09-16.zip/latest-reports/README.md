# Latest internal reports

Original working-language notes, internal acceptance records and raw audits for 423–425. Internal acceptance is not external peer review. Upstream sources are not all included.

- [THETA_CUBIC_REMAINDER_LOCATION.md](THETA_CUBIC_REMAINDER_LOCATION.md)
- [THETA_FIRST_JET_DEPTH.md](THETA_FIRST_JET_DEPTH.md)
- [THETA_JET_SPECTRAL_WIDTH.md](THETA_JET_SPECTRAL_WIDTH.md)
- [REVIEW_0423.md](REVIEW_0423.md)
- [REVIEW_0424.md](REVIEW_0424.md)
- [REVIEW_0425.md](REVIEW_0425.md)
- [task-0423.md](task-0423.md)
- [task-0424.md](task-0424.md)
- [task-0425.md](task-0425.md)
