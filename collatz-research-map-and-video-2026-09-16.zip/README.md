# Where We Stand on the Collatz Conjecture

An English, rotatable 3D research map and a four-minute narrated explanation.
**The full Collatz conjecture remains unproved in this project.**

Authors: **Khamit Kadyrbekov and Daniyal Kadirbekov**.
Snapshot: 16 September 2026. AI assistance is disclosed in the source notes.

The map contains 356 nodes and 532 relationships. Green means internally checked
within the stated scope, including conditional lemmas and identified limitations.
Unfilled nodes are open obligations. This is not a formally verified proof graph;
counts do not measure the fraction of the conjecture solved.

Open `index.html` directly in a browser, or serve this folder with any static
server. Drag the 3D map to rotate it. Select a node or use the search panel to read
its statement and related steps. Switch to 2D for a dependency layout. The
separate `complete.svg` contains every full label and can be zoomed independently.
Spatial positions have no mathematical interpretation. Rendering happens only
on interaction and resize; no continuous animation or force simulation runs.

The video explains the problem, why it matters, prior contributions by Terras,
Everett, Bernstein, Lagarias and Tao, the current project frontier, authorship,
and the remaining universal descent obligation. English synthetic narration uses
edge-tts. Burned captions and a separate timed subtitle file are supplied.

Read [SOURCES.md](SOURCES.md) for primary references, historical nuance, the exact
scope of Tao's result, and the boundary between published mathematics and our
internally reviewed work. The July 2026 revisions of Tao's paper are revisions
of his 2019/2022 result, not a full Collatz proof.

Latest local reduction: under the stated hypotheses in reports 424–425, the first
coefficient certificate has degree below 4d independent of matrix length H.
Its actual divisibility and height bounds, large-order contributions, and
universal coverage are not established. We do not claim to improve Tao's theorem
or establish novelty of every entry in this map.

Corrections and narrow lemma reviews are welcome through the repository's Issues.
Please identify the node/report, the exact hypothesis or calculation, and a
source or reproducible argument. Repository publication is not peer review.
