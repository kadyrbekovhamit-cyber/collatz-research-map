# Production record

Original vector illustrations and a nine-scene English narration.
edge-tts 7.2.8, en-US-JennyNeural, rate -3%, default pitch.
Real WordBoundary timing retained; captions are rounded to the nearest 24 fps frame.
Native sharp rendering: concurrency 1, sequential scene and caption-card jobs.
FFmpeg libx264: threads 1, filter_threads 1, filter_complex_threads 1.
Remotion editing source exists locally. Chromium export was blocked by the sandbox,
so the final frames were exported directly from SVG, then assembled with FFmpeg.
No audio was played during local quality checks. No voice cloning, music or
third-party images are used. Source images and script are supplied here.
